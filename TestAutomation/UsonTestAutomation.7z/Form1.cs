﻿using Microsoft.Web.Administration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UsonTestAutomation
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}


		private void Form1_Load(object sender, EventArgs e)
		{
			//try
			//{
			//	using (ServerManager serverManager = new ServerManager())
			//	{
			//		var site = serverManager.Sites.Where(s=>s.Name=="Default Web Site").FirstOrDefault();
			//		foreach (var application in site.Applications)
			//		{
			//			comboBox1.Items.Add(application.Path);
			//		}
			//	}
			//	if (comboBox1.Items.Count > 1)
			//	{
			//		comboBox1.SelectedIndex = 1;
			//	}
			//}
			//catch (Exception ex)
			//{
			//	MessageBox.Show("Cannot access IIS! " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			//}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			textBox1.Text = "http://localhost" + comboBox1.Text;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try {
				System.Diagnostics.Process.Start(textBox1.Text);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnTest1_Click(object sender, EventArgs e)
		{
			var driver = TestHelper.GetChromeDriver();
			TestHelper.AnalyzeClick(driver, textBox1.Text);
		}
	}
}
